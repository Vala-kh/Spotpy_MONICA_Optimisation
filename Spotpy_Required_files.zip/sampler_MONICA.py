import json
import os
import spotpy
import spotpy_setup_MONICA
import csv
from datetime import date
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors
from collections import defaultdict
import monica_io3
#change cur_dir
#start in powershell: 
#> monica-zmq-server -bi -i tcp://*:6666 -bo -o tcp://*:7777
#cur_dir="D:/MONICA/MONICA_Tutorial/MONICA_course/Day_4_Roland_Baatz/CalibrationCN/tutorial" 

pathup=os.getcwd()+'/..'
os.chdir(pathup)

font = {'family' : 'calibri',
    'weight' : 'normal',
    'size'   : 18}

def make_lambda(excel):
    return lambda v, p: eval(excel)


cultivar = "Cultivar4"#"the name of the cultivar for wet grassland" 

crop_sim_site_MAP = "crop_sim_site_MAP.csv"
observations = "Observations.csv"

#cur_dir = os.getcwd() 
os.chdir(os.getcwd())
#read general settings
exp_maps = []
basepath = os.path.dirname(os.path.abspath(__file__))
#cur_dir = os.getcwd() 
with open(os.path.join(basepath, crop_sim_site_MAP)) as exp_mapfile:
    dialect = csv.Sniffer().sniff(exp_mapfile.read(), delimiters=';,\t')
    exp_mapfile.seek(0)
    reader = csv.reader(exp_mapfile, dialect)   
    next(reader, None)  # skip the header
    for row in reader:
        exp_map = {}
        exp_map["exp_ID"] = row[0]
        exp_map["sim_file"] = os.path.join(basepath, "sim_file", row[1])
        exp_map["crop_file"] = os.path.join(basepath, "crop_file", row[2])
        exp_map["site_file"] = os.path.join(basepath, "site_file", row[3])
        exp_map["climate_file"] = os.path.join(basepath, "climate_file", row[4])
        exp_map["species_file"] = os.path.join(basepath, "param_files", row[5])
        exp_map["cultivar_file"] = os.path.join(basepath, "param_files", row[6])
        #exp_map["SoilOrganic_file"] = os.path.join(basepath, "param_files", row[7])
        exp_map["where_in_rotation"] = [int(x) for x in row[7].split("-")]
        exp_map["crop_ID"] = row[8]
        exp_maps.append(exp_map)

#read observations for which the likelihood of parameter space is calculated
obslist = [] #for envs (outputs)
with open(os.path.join(basepath, observations)) as obsfile:
    dialect = csv.Sniffer().sniff(obsfile.read(), delimiters=';,\t')
    obsfile.seek(0)
    reader = csv.reader(obsfile, dialect)
    next(reader, None)  # skip the header
    for row in reader:
        if row[3].upper() == "Y":
            record = {}
            record["exp_ID"] = row[0]
            record["DOY"] = int(row[1])
            record["value"] = float(row[2])           
            obslist.append(record) #TODO:Add weight here?



#read parameters which are to be calibrated
params = []
with open(os.path.join(basepath, "calibratethese.csv")) as paramscsv:
    dialect = csv.Sniffer().sniff(paramscsv.read(), delimiters=';,\t')
    paramscsv.seek(0)
    reader = csv.reader(paramscsv, dialect)
    next(reader, None)  # skip the header
    for row in reader:
        p={}
        p["name"] = row[0]
        p["array"] = row[1]
        p["low"] = row[2]
        p["high"] = row[3]
        p["stepsize"] = row[4]
        p["optguess"] = row[5]
        p["minbound"] = row[6]
        p["maxbound"] = row[7]
        if len(row) == 9 and row[8] != "":
            p["derive_function"] = make_lambda(row[8])
        params.append(p)


#Here, MONICA is initialized and a producer is started:
#Arguments are: Parameters, Sites, Observations
#Returns a ready made setup
spot_setup = spotpy_setup_MONICA.spot_setup(params, exp_maps, obslist)
#the same as for example: spot_setup = spot_setup(spotpy.objectivefunctions.rmse)
#Select maximum number of repititions

rep = 1100 #1100 iteration 
results = []
#Set up the sampler with the model above
sampler = spotpy.algorithms.sceua(spot_setup, dbname='SCEUAtry_monica_result', dbformat='csv')

#Run the sampler to produce the paranmeter distribution 
#and identify optimal parameters based on objective function
#ngs = number of complexes
#kstop = max number of evolution loops before convergence
#peps = convergence criterion
#pcento = percent change allowed in kstop loops before convergence 
sampler.sample(rep, ngs=len(params)*2, peps=0.001, pcento=0.001)

# run monica again with optimized params
s = sampler.status
if s.optimization_direction == "minimize":
    params = s.params_min
elif s.optimization_direction == "maximize":
    params = s.params_max
elif s.optimization_direction == "grid":
    print("Error: grid not implemented")
    exit(1)
opt_params = []
for i in range(s.parameters):
    opt_params.append(params[i])
opt_daily_result_msg = spot_setup.simulation(opt_params, daily_run=True)
opt_daily_result_msg = spot_setup.simulation([30.079, 0.202, 0.481, 4.80, 25.95, 32.29], daily_run=True)
with open("opt_daily_result_msg.json", "w") as _:
    _.write(json.dumps(opt_daily_result_msg))
out = monica_io3.write_output(opt_daily_result_msg["data"][0]["outputIds"], opt_daily_result_msg["data"][0]["results"])
with open("opt_daily_result.csv", "w") as _:
    for o in out:
        _.write(",".join(map(str, o)) + "\n")


#Extract the parameter samples from distribution
results = spotpy.analyser.load_csv_results("SCEUAtry_monica_result")


# Plot how the objective function was minimized during sampling
fig = plt.figure(1, figsize=(9, 6))
#plt.plot(results["like1"],  marker='o')
plt.plot(results["like1"],  'r+')
plt.show()
plt.ylabel("RMSE")
plt.xlabel("Iteration")
fig.savefig("SCEUAtry_objectivefunctiontrace.png", dpi=150)



# Plot how the objective function was minimized during sampling
fig = plt.figure(1, figsize=(9, 6))
plt.plot(results["like1"],  'r+')

plt.ylabel("RMSE")
plt.ylim(0, 65)
plt.xlabel("Iteration")
fig.savefig("SCEUAtry_objectivefunctiontrace.png", dpi=150)
plt.show()
print("sampler_MONICANO3.py finished")


