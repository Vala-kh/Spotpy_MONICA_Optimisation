import json
import sys
import monica_io3
import zmq
import csv
import os
from datetime import date
import collections
import threading
from threading import Thread
from collections import defaultdict


class monica_adapter(object):
    def __init__(self, exp_maps, obslist):

        #observations data structures
        self.observations = [] #for spotpy
        self.obs_doys = [] # for us :-)
        for record in obslist:
            self.observations.append(record["value"])
            self.obs_doys.append(record["DOY"])


        #create envs
        self.envs = []
        for exp_map in exp_maps:
            with open(exp_map["sim_file"]) as simfile:
                sim = json.load(simfile)
                sim["crop.json"] = exp_map["crop_file"]
                sim["site.json"] = exp_map["site_file"]
              

            with open(exp_map["site_file"]) as sitefile:
                site = json.load(sitefile)
                #site["SoilOrganicParameters"][1] = exp_map["SoilOrganic_file"] # In this speciefic example I don't use any parameter from soil like soil organic parameter, in case you use, should be announce here!

            with open(exp_map["crop_file"]) as cropfile:
                crop = json.load(cropfile)
                mycrop = exp_map["crop_ID"]
                crop["crops"][mycrop]["cropParams"]["species"][1] = exp_map["species_file"]  #My parameters are from species and cultivar from crop parameters, no param from general folder of monica_parameters
                crop["crops"][mycrop]["cropParams"]["cultivar"][1] = exp_map["cultivar_file"]
  

            env = monica_io3.create_env_json_from_json_config({
                "crop": crop,
                "site": site,
                "sim": sim,
                "climate": ""
            })
            
            #climate is read by the server
            env["csvViaHeaderOptions"] = sim["climate.csv-options"]
            env["csvViaHeaderOptions"]["start-date"] = sim["climate.csv-options"]["start-date"]
            env["csvViaHeaderOptions"]["end-date"] = sim["climate.csv-options"]["end-date"]
            env["pathToClimateCSV"] = []
            env["pathToClimateCSV"].append(exp_map["climate_file"])
            
            env["customId"] = exp_map["exp_ID"]
            self.envs.append(env)

        self.context = zmq.Context()
        self.socket_producer = self.context.socket(zmq.PUSH)
        self.socket_producer.connect("tcp://localhost:6666")

    def run(self,args):
        return self._run(*args)

    def _run(self, vector, daily_run=False):

        evallist = []
        self.out = {}
        
        #launch parallel thread for the collector
        collector = Thread(target=self.collect_results, kwargs={"daily_run": daily_run})
        collector.daemon = True
        collector.start()

        env = self.envs[0]
        cultivar_params = env["cropRotation"][0]["worksteps"][0]["crop"]["cropParams"]["cultivar"]
        species_params = env["cropRotation"][0]["worksteps"][0]["crop"]["cropParams"]["species"]
        cultivar_params["MaxAssimilationRate"] = vector[0]
        species_params["CuttingDelayDays"] = vector[1]
        species_params["PartBiologicalNFixation"] = vector[2] 

  
        events = []
        if daily_run:
            events = [
                "daily", [
                    "Date", "AbBiom", "GPP", "Crop"
                ]
            ]
        else:    
            add_days = 0
            for i, doy in enumerate(self.obs_doys):
                add_days = 0
                if i < len(self.obs_doys)-1 and self.obs_doys[i+1] < doy and add_days == 0:
                    add_days = 366
                events.append(["at", "days-since-start", "=", add_days + doy])

                events.append([ "AbBiom" ])
                
        env["events"] = events
      
        self.socket_producer.send_json(env)

        #wait until the collector finishes
        collector.join()
        
        if daily_run:
            return self.out
        else:
            #build the evaluation list for spotpy        
            ordered_out = collections.OrderedDict(sorted(self.out.items()))
            for k, v in ordered_out.items():
                for value in v:
                    #evallist.append(float(value[0])+float(value[1]))
                    evallist.append((value[0]))
            
        return evallist

        
    def collect_results(self, daily_run=False):
        socket_collector = self.context.socket(zmq.PULL)
        socket_collector.connect("tcp://localhost:7777")
        received_results = 0
        leave = False
        while not leave:
            try:
                #Start consumer here and save to json output
                rec_msg = socket_collector.recv_json()
            except:
                continue            
            
            if daily_run:
                self.out = rec_msg
                leave = True
            else:
                results_rec = []
                for res in rec_msg["data"]:
                    try:
                        results_rec.append([r[0] for r in res["results"]]) 
                    except:
                        print("no results in custom id " + rec_msg["customId"])
                self.out[int(rec_msg["customId"])] = results_rec

                received_results += 1


                if received_results == len(self.envs):
                    leave = True
